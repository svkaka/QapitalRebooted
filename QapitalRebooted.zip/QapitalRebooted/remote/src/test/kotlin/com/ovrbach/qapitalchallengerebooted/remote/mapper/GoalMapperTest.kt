package com.ovrbach.qapitalchallengerebooted.remote.mapper

import com.ovrbach.qapitalchallengerebooted.domain.entity.Goal
import com.ovrbach.qapitalchallengerebooted.remote.GoalDataFactory
import com.ovrbach.qapitalchallengerebooted.remote.entity.GoalModel
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import kotlin.test.assertEquals

@RunWith(JUnit4::class)
class GoalMapperTest {


    private val mapper = GoalMapper()

    @Test
    fun mapFromEntity() {
        val goalModel: GoalModel = GoalDataFactory.makeGoalModel()
        val goal: Goal = mapper.mapFromEntity(goalModel)

        assertEquals(goalModel.goalImageURL, goal.goalImageURL)
        assertEquals(goalModel.userId, goal.userId)
        assertEquals(goalModel.targetAmount, goal.targetAmount)
        assertEquals(goalModel.currentBalance, goal.currentBalance)
        assertEquals(goalModel.status, goal.status)
        assertEquals(goalModel.name, goal.name)
        assertEquals(goalModel.id, goal.id)
        assertEquals(goalModel.connectedUsers, goal.connectedUsers)
        assertEquals(goalModel.created, goal.created)
    }

    @Test
    fun mapToEntity() {
        val goal: Goal = GoalDataFactory.makeGoal()
        val goalModel: GoalModel = mapper.mapToEntity(goal)

        assertEquals(goal.goalImageURL, goalModel.goalImageURL)
        assertEquals(goal.userId, goalModel.userId)
        assertEquals(goal.targetAmount, goalModel.targetAmount)
        assertEquals(goal.currentBalance, goalModel.currentBalance)
        assertEquals(goal.status, goalModel.status)
        assertEquals(goal.name, goalModel.name)
        assertEquals(goal.id, goalModel.id)
        assertEquals(goal.connectedUsers, goalModel.connectedUsers)
        assertEquals(goal.created, goalModel.created)
    }
}