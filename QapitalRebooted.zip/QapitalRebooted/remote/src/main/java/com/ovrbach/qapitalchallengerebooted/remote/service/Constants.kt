package com.ovrbach.qapitalchallengerebooted.remote.service

const val BASE_URL = "https://qapital-ios-testtask.herokuapp.com/"
