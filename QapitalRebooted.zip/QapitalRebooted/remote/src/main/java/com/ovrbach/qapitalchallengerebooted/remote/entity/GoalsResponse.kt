package com.ovrbach.qapitalchallengerebooted.remote.entity

class GoalsResponse(
    val savingsGoals: List<GoalModel>
)