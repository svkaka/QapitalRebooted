package com.ovrbach.qapitalchallengerebooted.domain

abstract class Metadata(source: Source, val params: Params? = null){
    
}