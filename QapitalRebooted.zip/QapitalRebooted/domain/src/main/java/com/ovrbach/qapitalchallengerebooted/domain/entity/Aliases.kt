package com.ovrbach.qapitalchallengerebooted.domain.entity

typealias UserId = Int
typealias GoalId = Int
typealias FeedId = String