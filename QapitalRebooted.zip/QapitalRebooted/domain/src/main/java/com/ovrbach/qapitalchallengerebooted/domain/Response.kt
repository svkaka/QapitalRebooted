package com.ovrbach.qapitalchallengerebooted.domain

import com.ovrbach.qapitalchallengerebooted.domain.entity.GoalId

sealed class Response<T>(open val meta: Meta) {
    data class Success<T>(val data: T, override val meta: Meta) : Response<T>(meta)
    data class Error(val error: Throwable, override val meta: Meta) : Response<Nothing>(meta)
    data class Waiting(override val meta: Meta) : Response<Nothing>(meta)
}

abstract class Meta(val source: Source, val params: Params? = null)

enum class Source {
    LOCAL,
    REMOTE
}

abstract class Params()

class FetchFeedParams(val id: GoalId) : Params()